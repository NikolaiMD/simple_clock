class Clock {
  constructor() {
    let time = new Date();
    this.hours = time.getHours();
    this.minutes = time.getMinutes();
    this.seconds = time.getSeconds();
    if(this.seconds<=9){
      this.seconds=`0${this.seconds}`;
    };
    if(this.minutes<=9){
      this.minutes=`0${this.minutes}`
    };
    if(this.hours<=9){
      this.hours=`0${this.hours}`
    };
  };
  render(){
    let html = `<div class="clock"><div class="brand"><h6>SONY</h6></div><div class="digits">${c.hours} : ${c.minutes} : ${c.seconds}</div></div>`;
    document.write(html);
  };
};
let c = new Clock;
c.render();
setTimeout(function(){location.reload()}, 1000);
